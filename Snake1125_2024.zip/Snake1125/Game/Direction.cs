﻿namespace Snake1125
{
    public enum Direction
    {
        right,
        left,
        up,        
        down
    }
}