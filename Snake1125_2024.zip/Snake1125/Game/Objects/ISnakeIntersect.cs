﻿using Snake1125.Game.Objects;

namespace Snake1125
{
    internal interface ISnakeIntersect
    {
        void Execute(Snake snake);
    }
}