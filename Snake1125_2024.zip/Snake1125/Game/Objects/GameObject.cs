﻿
namespace Snake1125.Game.Objects
{
    public class GameObject
    {
        public virtual int X { get; set; }
        public virtual int Y { get; set; }        
    }
}